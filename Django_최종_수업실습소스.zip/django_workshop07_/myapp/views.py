from django.shortcuts import render
from django.http.response import HttpResponseRedirect

# Create your views here.
data = [{"username":"홍길동","age":20,"address":"서울","email":"aaa254@gmail.com"},
    {"username":"이순신","age":30,"address":"경기","email":"bbb.lee@gmail.com"},
    {"username":"유관순","age":40,"address":"부산","email":"ccc@gmail.com"},
    {"username":"강감찬","age":50,"address":"광주","email":"ddd.kang@gmail.com"},
    {"username":"세종","age":70,"address":"서울","email":"eee@gmail.com"},
    {"username":"세종대왕","age":83,"address":"제주","email":"fff@gmail.com"},
    {"username":"윤봉길","age":34,"address":"강원","email":"ggg@gmail.com"},]
    
def list(request):
    # 문자열 형태의  json형식의 리스트인 경우: json.loads(data)
    return render(request, "list.html" , {"list":data})


def retrieve(request):
    
    email = request.GET.get("email")
    print(email)
    user = {}
    for p in data:
        if p['email'] == email:
            user = p
    print(user)
    return render(request, "retrieve.html" , user )


def memberForm(request):

    return render(request, "memberForm.html" )

def memberAdd(request):
    
    email = request.POST.get("email")
    username = request.POST.get("username")
    age = request.POST.get("age")
    address = request.POST.get("address")
    
    user ={}
    user['email']=email
    user['username']=username
    user['age']=age
    user['address']=address

    data.append(user)
    print(data)
    return HttpResponseRedirect("/member/list")

def memberDel(request):
    
    
    email = request.GET.get("email")
    print(email)
    for idx, p in enumerate(data): # enumerate(data, 1)
        if p['email'] == email:
            data.pop(idx)

    return HttpResponseRedirect("/member/list")



def memberDelAll(request):
    
    #########################
#     arr = [11,20,32,41]
#     # list comprehension ==> 기존의 리스트에서 변형된 결과를 리스트로 반환
#     arr_2 = [x for x in arr]
#     print(arr_2)
#     arr_3 = [x+1 for x in arr]
#     print(arr_3)
#     arr_4 = [x > 30 for x in arr]
#     print(arr_4)
#     arr_5 = [x  for x in arr if x%2==0]
#     print(arr_5)
#     arr_6 = [x if x%2==0 else -x  for x in arr ]
#     print(arr_6)
    #########################
    global data
    email_list = request.GET.getlist("delAll")
    
    new_data = [ p for p in data if p['email'] not in email_list]
    data = new_data
    
#     print(email_list)
#     for idx, p in enumerate(data): # enumerate(data, 1)
#         for email in email_list:
#             if p['email'] == email:
#                 data.pop(idx) # 기존 인덱스 변경문제 발생
    
    return HttpResponseRedirect("/member/list")






