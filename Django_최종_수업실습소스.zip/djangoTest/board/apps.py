from django.apps import AppConfig


class BoardConfig(AppConfig):
    name = 'board'

