'''
Created on 2020. 9. 23

@author: Student
'''

num2 = 10




