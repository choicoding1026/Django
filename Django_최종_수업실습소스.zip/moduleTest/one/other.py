'''
Created on 2020. 9. 23

@author: Student
'''

num = 10

def fun1():
    print("fun1")
    
class Person:
    pass


print("one.other.py >> ", __name__)

