'''
Created on 2020. 9. 23

@author: Student
'''
size = 100

def fun2():
    print("fun2")
