'''
  1) 모듈 (module)
     - 파이썬 파일( *.py)
  
  2) 패키지 (package)
    - 여러 모듈(파일)중에서  서로 관련된 파일들의 묶음.
    
 ==> 모듈이 다르면 접근이 불가능하다.
     가능하게 하도록 import로 처리해야 된다.
    import는 사용하고자 하는 요소(변수,함수,클래스...)의
    경로를 지정하는 방법이다.   
    
  # 외부 파일 (다른 모듈) 접근 방법
  
  1) 경로 지정
     import 패키지명.모듈명
     import 패키지명.모듈명 as 별칭
     
  2) 경로지정
     from 패키지명  import 모듈명
     from 패키지명  import 모듈명, 모듈명2
    
  3) 경로지정
    from 패키지명.모듈명   import 변수명,함수명,클래스명
   
   
   결론적으로 내안에서 정의하지 않은 요소접근은
   반드시 import문을 사용해야 된다.
       
'''

from one.other import num, fun1, Person
from two.theOther import size, fun2

print(num)
fun1()
p = Person()

print(size)
fun2()




















