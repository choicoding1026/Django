'''
  1) 모듈 (module)
     - 파이썬 파일( *.py)
  
  2) 패키지 (package)
    - 여러 모듈(파일)중에서  서로 관련된 파일들의 묶음.
    
 ==> 모듈이 다르면 접근이 불가능하다.
     가능하게 하도록 import로 처리해야 된다.
    import는 사용하고자 하는 요소(변수,함수,클래스...)의
    경로를 지정하는 방법이다.   
    
  # 외부 파일 (다른 모듈) 접근 방법
  
  1) 경로 지정
     import 패키지명.모듈명
     import 패키지명.모듈명 as 별칭
     
  2) 경로지정
     from 패키지명  import 모듈명
     from 패키지명  import 모듈명, 모듈명2
    
  3) 경로지정
    from 패키지명.모듈명   import 변수명,함수명,클래스명
   
   
   결론적으로 내안에서 정의하지 않은 요소접근은
   반드시 import문을 사용해야 된다.
       
  * python 언어는 시작점(starting point)
  역할하는  다른 프로그램 언어의  main과 같은 
  기능의 함수가 없다. 따라서 각각의 모듈(파일)이
  독립적으로 실행이 가능하다.
  시작점 역할을 하는 클래스에서는 반드시
  main함수와 같은 코드를 관례적으로 사용해서 쓴다.
  
  if __name__ == "__main__":
       pass
   
       
'''
from one.other import num


if __name__ == "__main__":

    print("sample05.py >> ", __name__)
    print(num)


















