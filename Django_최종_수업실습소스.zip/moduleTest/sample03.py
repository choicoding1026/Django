'''
  1) 모듈 (module)
     - 파이썬 파일( *.py)
  
  2) 패키지 (package)
    - 여러 모듈(파일)중에서  서로 관련된 파일들의 묶음.
    
 ==> 모듈이 다르면 접근이 불가능하다.
     가능하게 하도록 import로 처리해야 된다.
    import는 사용하고자 하는 요소(변수,함수,클래스...)의
    경로를 지정하는 방법이다.   
    
  # 외부 파일 (다른 모듈) 접근 방법
  1) 경로 지정
     import 패키지명.모듈명
     import 패키지명.모듈명 as 별칭
     
  2) 경로지정
     from 패키지명  import 모듈명
     from 패키지명  import 모듈명, 모듈명2
    
'''
from one import other, other2
from two import theOther

print(other.num)
print(other2.num2)
other.fun1()
p = other.Person()

print(theOther.size)
theOther.fun2()
















