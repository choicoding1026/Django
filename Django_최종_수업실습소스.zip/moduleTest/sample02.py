'''
  1) 모듈 (module)
     - 파이썬 파일( *.py)
  
  2) 패키지 (package)
    - 여러 모듈(파일)중에서  서로 관련된 파일들의 묶음.
    
 ==> 모듈이 다르면 접근이 불가능하다.
     가능하게 하도록 import로 처리해야 된다.
    import는 사용하고자 하는 요소(변수,함수,클래스...)의
    경로를 지정하는 방법이다.   
    
  # 외부 파일 (다른 모듈) 접근 방법
  1) 경로 지정
     import 패키지명.모듈명
     import 패키지명.모듈명 as 별칭
    
'''

import one.other as xxx
import two.theOther as yyy

import numpy as np
import pandas as pd


print(xxx.num)
xxx.fun1()

p = xxx.Person()

print(yyy.size)
yyy.fun2()






