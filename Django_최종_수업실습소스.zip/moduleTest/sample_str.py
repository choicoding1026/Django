'''
Created on 2020. 9. 23

@author: Student
'''

class User:
    
    def __init__(self, username, age):
        self.username = username
        self.age = age
        
    def __str__(self): # 매직 함수(메서드)
        return self.username +"\t" + str(self.age)   
     
p = User("홍길동", 20)
print(p.username)
print(p.age)
print(p)
        
        
# print(dir(str))        
        
        
        
