from django.shortcuts import render

# Create your views here.
def a(request):
    
    return render(request, 'template_inheritance.html')

def a2(request):
    
    return render(request, 'template_inheritance2.html')