from django.shortcuts import render

# Create your views here.
def memberForm(request):
        
    return render(request, "memberForm.html")


def memberInfo(request):
    user = {}

    username = request.POST.get("username")
    ssn = request.POST.get("ssn")
    gender = "남자" if ssn[7:8]=="1" else "여자" 
    
    hobby = request.POST.getlist('hobby')
    marry = request.POST.get("marry")
        
    user['username']=username
    user['gender']=gender
    user['hobby']=" ".join(hobby)
    user['marry']=marry
        
    return render(request,"memberInfo.html", user)