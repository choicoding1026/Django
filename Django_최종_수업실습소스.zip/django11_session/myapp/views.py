from django.shortcuts import render
from django.http.response import HttpResponseRedirect

# Create your views here.
def session(request):
    return render(request, 'session.html')


def loginForm(request):
    return render(request, 'loginForm.html')


def login(request):
    
    userid = request.GET.get("userid")
    passwd = request.GET.get("passwd")
    
    # DB 연동해서 아이디 검사 필요
    
    # 필요한 데이터를 서버 메모리인 세션에 저장
    # 저장문법:  request.sesssion[key]=value
    request.session['userid']=userid

    return render(request, 'login.html')

def loginInfo(request):
    # 로그인 처리 여부 확인
    if 'userid' in request.session:
        
        print(request.session.keys()) # dict_keys(['userid'])
        print(request.session.items()) # dict_items([('userid', 'aaa')])
        print(request.session.values()) # dict_values(['aaa'])
        print(request.session.get('userid')) # aaa
        
        return render(request, 'loginInfo.html')
    else:
        return HttpResponseRedirect("/main/loginForm")
    
def logout(request):
    # 로그인 처리 여부 확인
    if 'userid' in request.session:
        request.session.flush()
        return render(request, 'logout.html')
    else:
        return HttpResponseRedirect("/main/loginForm")


