from django.shortcuts import render

# Create your views here.
def link(request):

    return render(request, 'link.html')


def memberAdd(request):
    print("memberAdd")
    return render(request, 'a.html')

def memberDel(request):
    print("memberDel")   
    return render(request, 'a.html')