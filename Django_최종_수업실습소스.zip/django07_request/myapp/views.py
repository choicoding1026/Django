from django.shortcuts import render
from django.core.handlers.wsgi import WSGIRequest

# Create your views here.
def loginForm(request):
    
    return render(request, 'loginForm.html')

def loginGet(request):
    print(request.GET)
    userid = request.GET.get("userid","기본값") # key값이 다른경우 None, 기본값 설정 가능
    passwd = request.GET.get("passwd")
    phone = request.GET.getlist("phone")
    print(userid, passwd, phone)
    user ={}
    user['userid']=userid
    user['passwd']=passwd
    user['phone']=phone
    return render(request, 'loginInfo.html', user)

def loginPost(request):
    userid = request.POST.get("userid")
    passwd = request.POST.get("passwd")
    phone = request.POST.getlist("phone")
    print(userid, passwd, phone)
    return render(request, 'loginInfo.html')



def login99(request):
    # 아이디와 비번을 얻는다.    
    print("request:", request)# <WSGIRequest: GET '/main/login/?userid=asdf&passwd=22'>
    print("WSGIRequest:", dir(WSGIRequest))
    print("WSGIRequest.body(get):", request.body) # WSGIRequest.boyd: b''
    print("WSGIRequest.body(post):", request.body) # WSGIRequest.boyd: b''
    print("WSGIRequest.content_params:", request.content_params) # {}
    print("WSGIRequest.content_type:", request.content_type) #text/plain
    print("WSGIRequest.COOKIES:", request.COOKIES) # {}
    print("WSGIRequest.FILES:", request.FILES) # <MultiValueDict: {}>
    print("WSGIRequest.GET:", request.GET) # <QueryDict: {'userid': ['eee'], 'passwd': ['2322']}>
    print("WSGIRequest.POST:", request.POST) # <QueryDict: {}>
    print("WSGIRequest.encoding:", request.encoding) # None
    print("WSGIRequest.accepts:", request.accepts('userAgent')) # True
    print("WSGIRequest.build_absolute_uri:", request.build_absolute_uri()) # http://localhost:8000/main/login/?userid=eee&passwd=2322
    print("WSGIRequest.get_full_path:", request.get_full_path()) # /main/login/?userid=eee&passwd=2322
    print("WSGIRequest.get_full_path_info:", request.get_full_path_info()) # /main/login/?userid=eee&passwd=2322
    print("WSGIRequest.get_host:", request.get_host()) #  localhost:8000
    print("WSGIRequest.get_port:", request.get_port()) # 8000
    print("WSGIRequest.scheme:", request.scheme) # http
    print("WSGIRequest.headers:", request.headers) # {'Content-Length': '', 'Content-Type': 'text/plain', 'Host': 'localhost:8000', 'Connection': 'keep-alive', 'Cache-Control': 'max-age=0', 'Upgrade-Insecure-Requests': '1', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'Sec-Fetch-Site': 'same-origin', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-User': '?1', 'Sec-Fetch-Dest': 'document', 'Referer': 'http://localhost:8000/main/loginForm/', 'Accept-Encoding': 'gzip, deflate, br', 'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7'}
    '''
    ['COOKIES', 'FILES', 'GET', 'POST',
     '__class__', '__delattr__', '__dict__',
      '__dir__', '__doc__', '__eq__', '__format__',
       '__ge__', '__getattribute__', '__gt__', '__hash__', '__init__',
        '__init_subclass__', '__iter__', '__le__', '__lt__', '__module__',
         '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__',
          '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 
          '__weakref__', '_current_scheme_host', '_encoding', '_get_full_path',
           '_get_post', '_get_raw_host', '_get_scheme', '_initialize_handlers',
            '_load_post_and_files', '_mark_post_parse_error',
             '_set_content_type_params', '_set_post', '_upload_handlers',
              'accepted_types', 'accepts', 'body', 'build_absolute_uri',
               'close', 'encoding', 'get_full_path',
                'get_full_path_info', 'get_host',
                 'get_port', 'get_raw_uri',
                  'get_signed_cookie',
                   'headers', 'is_ajax',
                    'is_secure', 'parse_file_upload',
                     'read', 'readline',
                      'readlines', 'scheme', 'upload_handlers']
    '''
    
    return render(request, 'loginInfo.html')