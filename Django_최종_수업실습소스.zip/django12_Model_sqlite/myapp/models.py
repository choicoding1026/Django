from django.db import models

# Create your models here.
# 여기에 만든 클래스는 자동으로 DB의 테이블로 생성된다.

class Product(models.Model):
    code = models.CharField(max_length=64, primary_key=True)
    name = models.CharField(max_length=64)
    price = models.IntegerField()
    pub_date = models.DateTimeField(auto_now_add=True)