from django.shortcuts import render
from django.http.response import HttpResponseRedirect

# Create your views here.
def session(request):
    return render(request, 'session.html')


def loginForm(request):
    return render(request, 'loginForm.html')


def login(request):
    
    userid = request.GET.get("userid")
    passwd = request.GET.get("passwd")
    
    # DB 연동해서 아이디 검사 필요
    
    # 필요한 데이터를 클라이언트인 브라우저에 저장- 쿠키(cookie)
    
    response = render(request, 'login.html') 
    print(dir(response))
    '''
    ['__bytes__', '__class__', '__contains__', '__delattr__', 
    '__delitem__', '__dict__', '__dir__', '__doc__', '__eq__', 
    '__format__', '__ge__', '__getattribute__', '__getitem__', 
    '__gt__', '__hash__', '__init__', '__init_subclass__', 
    '__iter__', '__le__', '__lt__', '__module__', '__ne__', 
    '__new__', '__reduce__', '__reduce_ex__', '__repr__', 
    '__setattr__', '__setitem__', '__sizeof__', '__str__', 
    '__subclasshook__', '__weakref__', '_charset', '_container',
     '_content_type_for_repr', '_convert_to_charset', 
     '_handler_class', '_headers', '_reason_phrase', 
     '_resource_closers', 'charset', 'close', 'closed',
      'content', 'cookies', 'delete_cookie', 'flush',
       'get', 'getvalue', 'has_header', 'items', 
       'make_bytes', 'readable', 'reason_phrase',
        'seekable', 'serialize', 'serialize_headers',
         'set_cookie', 'set_signed_cookie', 'setdefault',
          'status_code', 'streaming', 'tell', 'writable',
           'write', 'writelines']
    '''
    response.set_cookie("userid", userid, 3600) # 3600초, 1시간
    return response

def loginInfo(request):
    # 로그인 처리 여부 확인
    userid = request.COOKIES.get("userid")
    if userid :
        return render(request, 'loginInfo.html')
    else:
        return HttpResponseRedirect("/main/loginForm")
    
def logout(request):
    # 로그인 처리 여부 확인
    userid = request.COOKIES.get("userid")
    if userid :
        response = render(request, 'logout.html') 
        response.delete_cookie("userid")
        return response
    else:
        return HttpResponseRedirect("/main/loginForm")


