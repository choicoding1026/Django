from django.shortcuts import render

# Create your views here.
def a(request):
    
    return render(request,"static_file.html")