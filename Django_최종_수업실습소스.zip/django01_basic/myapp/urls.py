# application 단위의 urls.py
from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    #path('yyy/', "views.py 에 정의된 함수지정"),
    path('yyy/', views.hello_print),
]
