

from django.shortcuts import render
from django.http.response import HttpResponse

# Create your views here.

def hello_print(request):
    # 로직처리( querystring얻기, Model연동,......
    # 로직처리후 화면 생성해서 return한다.
    return HttpResponse("<h1>Hello</h1>")
