from django.shortcuts import render
from django.http.response import HttpResponse, HttpResponseRedirect

# Create your views here.

# 1. 직접 HttpResponse 객체 이용해서 HTML 작성
def a(request):
    
    return HttpResponse("<p>HTML직접 작성, HttpResponse</p>")

# 2. 포워드(forward) 방식: render 함수이용해서 외부 파일인 html 지정 ==> b.html에 요청한 것이다.
#  URL 변경 안됨.
def b(request):
    return render(request, "b.html")

# 3. 리다이렉트(redirect)방식: HttpResponseRedirect 사용, URL 변경 됨.
def c(request):
    
    return HttpResponseRedirect("/main/a") # 재요청하고싶은 path지정


