'''
Created on 2020. 9. 24

@author: Student
'''
# 시간 관련
import time

# 1970년 1월 1일 0시 0분 0초 부터 현재까지의 경과시간을 초단위로 반환
print("1. 현재시간구하기(1970~현재)초단위:", time.time()) 
time_date = time.localtime(time.time())
print("2. 현재시간구하기:", time_date)
print("4. 현재년도:", time_date.tm_year)
print("5. 현재월:", time_date.tm_mon)
print("6. 현재일:", time_date.tm_mday)
print("7. 현재시간:", time_date.tm_hour)
print("8. 현재분:", time_date.tm_min)
print("9. 현재초:", time_date.tm_sec)
print("10. 현재요일:", time_date.tm_wday) #월 ~ 일 ( 0 ~ 6 )
print()
# 특정 포맷으로 출력
time_format = time.strftime("%Y 년 %m 월  %d 일, %H:%M:%S %p", time_date)
print(time_format)
print(help(time.strftime))

#  %Y  Year with century as a decimal number.
#     %m  Month as a decimal number [01,12].
#     %d  Day of the month as a decimal number [01,31].
#     %H  Hour (24-hour clock) as a decimal number [00,23].
#     %M  Minute as a decimal number [00,59].
#     %S  Second as a decimal number [00,61].
#     %z  Time zone offset from UTC.
#     %a  Locale's abbreviated weekday name.
#     %A  Locale's full weekday name.
#     %b  Locale's abbreviated month name.
#     %B  Locale's full month name.
#     %c  Locale's appropriate date and time representation.
#     %I  Hour (12-hour clock) as a decimal number [01,12].
#     %p  Locale's equivalent of either AM or PM.




