'''
Created on 2020. 9. 24

@author: Student
'''
from datetime import datetime

print("1. 현재날짜:(now함수)", datetime.now())
print("1. 현재날짜:(today함수)", datetime.today())
print("2. 현재년도:", datetime.today().year)
print("3. 현재월:", datetime.today().month)
print("4. 현재일:", datetime.today().day)
print("5. 현재시간:", datetime.today().hour)
print("6. 현재분:", datetime.today().minute)
print("7. 현재초:", datetime.today().second)
print("8. 현재 밀리초:", datetime.today().microsecond) # 1/1000 초
print()

# 2. 특정 날짜와 시간으로 datetime 생성
print(help(datetime))
#datetime(year, month, day[, hour[, minute[, second[, microsecond[,tzinfo]]]]])
user_datetime = datetime(year=2010,month=12,day=12, hour=13 , minute=12)
print("9. 사용자정의 datetiem 객체:",user_datetime)
print(user_datetime.year, user_datetime.month, user_datetime.day)

# 3. 문자열 형태의 날짜 --> 날짜 객체
str_date = '1985-12-21'
date_date = datetime.strptime(str_date, '%Y-%m-%d')
print("10. 문자열날짜 --> 날짜객체로 변환:", date_date)
print(date_date.year, date_date.month)

# 4. 날짜 객체 -- > 문자열 형태의 날짜 
str2_date = date_date.strftime('%Y 년 %m 월  %d 일 ')
print("11.날짜객체 --> 문자날짜로", str2_date)









